package examOnSchool.examOnSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamOnSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamOnSchoolApplication.class, args);
	}

}
