package examOnSchool.examOnSchool.service;

import examOnSchool.examOnSchool.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    List<User> getAllUser();

    Optional<User> getUserById(Long id);

    User addUser(User user);
    void deleteUser(Long id);
    User updateUser(Long id, User updatedUser);
}
